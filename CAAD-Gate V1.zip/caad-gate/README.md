# CAAD-Gate

**Context-Aware Adaptive Data Gate for Low-Power Edge-IoT Devices**

CAAD-Gate is a reusable firmware-level edge-intelligence framework for ESP32-class IoT devices. It helps embedded systems learn normal sensor behaviour and forward only meaningful, abnormal, or contextually important data to ML, alerting, or communication.

In simple words:

> CAAD-Gate helps small IoT devices decide what data is worth processing and what data should be ignored.

---

## Why CAAD-Gate exists

Small IoT devices continuously collect sensor data, but most of that data is normal. Processing every sound frame, motion window, or temperature reading can waste CPU time, memory, battery power, and communication bandwidth.

Many low-cost systems use fixed thresholds, but fixed thresholds are weak when the environment, user, device, or machine changes.

CAAD-Gate solves this by learning local normal behaviour and opening the gate only when the current sensor window becomes meaningful.

```text
Normal data        -> Gate CLOSED -> save processing
Important event    -> Gate OPEN   -> ML / alert / communication
```

---

## What CAAD-Gate is

CAAD-Gate is best described as a:

- reusable firmware-level framework,
- lightweight pre-ML decision layer,
- adaptive edge-intelligence middleware,
- sensor-agnostic gating engine for IoT products.

It is not a final ML classifier. It decides **when** ML, alerting, or communication should run.

---

## Framework architecture

```text
Raw sensor data
      ↓
Sensor-specific module
      ↓
CAADFeatures packet
      ↓
CAAD-Gate Core Engine
      ↓
CAADDecision output
      ↓
ML / Alert / Communication / Save Processing
```

### Common core engine

The core engine handles:

- normal behaviour learning,
- adaptive thresholding,
- context-aware decision-making,
- gate open / closed decision,
- reason output,
- processing-saving estimation,
- safe baseline update.

### Separate sensor modules

Different sensors connect to the same core engine:

| Module | Sensor / scenario | Purpose |
|---|---|---|
| `CAADSoundGate` | microphone / sound energy | forwards meaningful sound events |
| `CAADMotionGate` | accelerometer / motion | forwards fall-candidate or abnormal motion windows |
| `CAADEnvironmentGate` | temperature / air quality / machine sensor | forwards abnormal environmental or machine-condition changes |
| `CAADCustomGateTemplate` | new user-defined sensor | starter module for new scenarios |

---

## Key concept

CAAD-Gate uses lightweight features:

```text
level
variation
rate of change
peak value
duration evidence
context importance
confidence
validity
```

Then the core learns what normal means and calculates whether the current window is important enough to pass.

---

## Context-aware behaviour

CAAD-Gate is not only adaptive thresholding. It can also use context:

```text
battery level
low-power mode
CPU / memory pressure
urgency
risk level
alert mode
user/application sensitivity
```

Example:

- high-risk eldercare context -> more sensitive gate,
- low battery mode -> stricter gate,
- machine under load -> stronger attention to abnormal changes.

---

## Folder structure

```text
caad-gate/
│
├── src/
│   ├── CAADGateCore.h
│   ├── CAADGateCore.cpp
│   ├── CAADTypes.h
│   ├── CAADContext.h
│   └── modules/
│       ├── CAADSoundGate.h / .cpp
│       ├── CAADMotionGate.h / .cpp
│       ├── CAADEnvironmentGate.h / .cpp
│       └── CAADCustomGateTemplate.h / .cpp
│
├── examples/
│   ├── ESP32_Temperature_Monitor_Demo/
│   ├── ESP32_Motion_Fall_Candidate_Demo/
│   ├── ESP32_LilyGO_Sound_Display_Demo/
│   ├── ESP32_Sound_Awareness_Node/
│   ├── ESP32_Environment_Monitor/
│   └── ESP32_Eldercare_Motion_Node/
│
├── docs/
│   ├── Framework_Explanation.md
│   ├── How_To_Add_New_Sensor_Module.md
│   ├── Theory_Explanation.md
│   ├── Module_Reference.md
│   └── BUILD_CHECK.md
│
├── tests/
│   └── portable_compile_test.cpp
│
├── library.properties
├── LICENSE
├── .gitignore
└── README.md
```

---

## Quick Arduino usage

```cpp
#include <CAADGateCore.h>
#include <modules/CAADEnvironmentGate.h>

CAADGateCore gateCore;
CAADEnvironmentGate envGate;
CAADContext context;

void setup() {
  Serial.begin(115200);
  gateCore.begin();
  envGate.begin();
}

void loop() {
  float temperature = readTemperatureC();

  CAADFeatures features = envGate.update(temperature, millis());
  CAADDecision decision = gateCore.update(features, context);

  if (decision.gateOpen) {
    // Run ML, send alert, log event, or communicate to cloud
  } else {
    // Normal / low-relevance data: save processing
  }
}
```

---

## Examples included

### 1. Temperature / machine monitoring demo

Folder:

```text
examples/ESP32_Temperature_Monitor_Demo
```

Shows how CAAD-Gate learns a normal temperature baseline and opens for abnormal temperature rises.

### 2. Motion / fall-candidate demo

Folder:

```text
examples/ESP32_Motion_Fall_Candidate_Demo
```

Shows how CAAD-Gate forwards abnormal motion windows for fall-candidate checking. It does not medically confirm a fall.

### 3. LilyGO sound display demo

Folder:

```text
examples/ESP32_LilyGO_Sound_Display_Demo
```

Shows live gate behaviour on a LilyGO display using an INMP441 I2S microphone.

Judges should see:

```text
Quiet background -> Gate CLOSED
Clap / knock     -> Gate OPEN
Quiet again      -> Gate CLOSED
```

---

## How to add a new sensor

Read:

```text
docs/How_To_Add_New_Sensor_Module.md
```

Start from:

```text
src/modules/CAADCustomGateTemplate.h
src/modules/CAADCustomGateTemplate.cpp
```

Rename the template and map your sensor values into `CAADFeatures`.

---

## Installation in Arduino IDE

1. Download or clone this repository.
2. Copy the `caad-gate` folder into your Arduino `libraries` folder.
3. Restart Arduino IDE.
4. Open an example from `File -> Examples -> CAAD-Gate`.
5. Select your ESP32 board.
6. Upload and open Serial Monitor at 115200 baud.

---

## Recommended competition explanation

> CAAD-Gate is a reusable adaptive data-gating framework for low-power IoT devices. The common core learns normal behaviour and decides whether each sensor window should be ignored or forwarded. Sensor modules allow sound, motion, temperature, air quality, and other devices to use the same core decision logic.

---

## Current status

CAAD-Gate V1 includes:

- reusable core engine,
- sound, motion, and environment modules,
- custom module template,
- Arduino/ESP32 examples,
- LilyGO sound display demo,
- documentation for extension.

---

## License

This project is released under the MIT License. See `LICENSE`.


# Build Check

A portable C++ compile check was run for the reusable framework files.

Checked files:

```text
src/CAADGateCore.cpp
src/modules/CAADSoundGate.cpp
src/modules/CAADMotionGate.cpp
src/modules/CAADEnvironmentGate.cpp
src/modules/CAADCustomGateTemplate.cpp
tests/portable_compile_test.cpp
```

Command used:

```bash
g++ -std=c++11 -Isrc -Isrc/modules \
  tests/portable_compile_test.cpp \
  src/CAADGateCore.cpp \
  src/modules/CAADSoundGate.cpp \
  src/modules/CAADMotionGate.cpp \
  src/modules/CAADEnvironmentGate.cpp \
  src/modules/CAADCustomGateTemplate.cpp \
  -o tests/portable_compile_test
```

Result:

```text
CAAD-Gate portable compile test PASS
```

Important note:

- The reusable C++ core and modules compile in a normal C++ environment.
- Arduino examples still need the correct ESP32 board package and any required sensor/display libraries.
- The LilyGO display demo needs `TFT_eSPI` configured for the exact LilyGO board.

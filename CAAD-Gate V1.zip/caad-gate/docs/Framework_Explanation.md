# CAAD-Gate Framework Explanation

## What is CAAD-Gate?

CAAD-Gate is a **Context-Aware Adaptive Data Gate** for low-power IoT and embedded edge devices.

It runs before heavy processing such as ML inference, sound classification, alerting, wireless communication, or cloud upload.

Its main question is:

> Is this sensor data window worth processing now?

If yes, the gate opens. If no, the gate closes and the device saves processing.

## Why it is a framework

CAAD-Gate is not only one Arduino sketch. It provides a reusable structure:

```text
Sensor data
   ↓
Sensor module
   ↓
CAADFeatures packet
   ↓
CAAD-Gate Core Engine
   ↓
CAADDecision output
   ↓
ML / alert / communication / sleep
```

The framework includes:

1. A common core engine.
2. A standard feature input packet.
3. A standard decision output packet.
4. Separate sensor modules.
5. Example applications.
6. Documentation for adding new sensors.

## Common core engine

The core handles:

- normal behaviour learning,
- adaptive thresholding,
- context-aware decision adjustment,
- gate open / closed output,
- human-readable reason output,
- processing-saving estimation,
- safe baseline update.

## Sensor modules

Sensor modules prepare data for the core.

| Module | Input | Example use |
|---|---|---|
| `CAADSoundGate` | audio frame / energy | sound event gating |
| `CAADMotionGate` | accelerometer X/Y/Z | fall-candidate forwarding |
| `CAADEnvironmentGate` | scalar sensor value | temperature, AQI, machine monitoring |
| `CAADCustomGateTemplate` | generic scalar value | new sensor modules |

## Standard feature packet

Every module produces `CAADFeatures`:

```cpp
CAADFeatures features;
features.level;
features.variation;
features.rateOfChange;
features.peak;
features.durationEvidence;
features.contextImportance;
features.confidence;
features.valid;
features.allowNormalUpdate;
```

## Standard decision output

The core returns `CAADDecision`:

```cpp
CAADDecision decision;
decision.gateOpen;
decision.state;
decision.relevanceScore;
decision.adaptiveThreshold;
decision.normalMean;
decision.processingReductionPercent;
decision.reasonCode;
```

## What makes it context-aware?

The core can use `CAADContext`:

```cpp
CAADContext context;
context.batteryPercent = 80;
context.lowPowerMode = false;
context.sensitivity = 0.2;
context.urgency = 0.1;
context.alertMode = false;
```

Context changes the gate sensitivity:

- high urgency -> more sensitive,
- alert mode -> more sensitive,
- low battery -> stricter,
- high CPU/memory pressure -> stricter.

## Correct positioning

CAAD-Gate is not the final ML classifier.

It does not say:

> This is definitely a fall.

It says:

> This motion window is important enough to forward for fall-candidate checking.

It does not say:

> This sound is definitely an alarm.

It says:

> This sound frame is active enough to forward to recognition.

That is why CAAD-Gate is a **pre-ML decision engine**.


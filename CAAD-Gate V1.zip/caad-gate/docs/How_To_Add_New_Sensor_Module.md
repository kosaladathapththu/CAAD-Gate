# How to Add a New Sensor Module to CAAD-Gate

CAAD-Gate is designed as a reusable framework. The **core engine** stays the same, while each new sensor needs a small **sensor module** that converts raw sensor data into a standard `CAADFeatures` packet.

## 1. The main idea

Every sensor is different, but most sensor streams can be described using a few simple features:

| CAADFeature | Meaning | Example |
|---|---|---|
| `level` | Main current value | temperature, sound energy, vibration level |
| `variation` | How unstable the value is | noisy signal, fluctuating gas value |
| `rateOfChange` | How fast it changed | sudden temperature rise |
| `peak` | Highest recent value | impact peak, high gas value |
| `durationEvidence` | Whether the event lasts long enough | abnormal for several windows |
| `contextImportance` | Application-level importance | high-risk mode, sensitive user |
| `confidence` | Sensor reliability | 1.0 = trusted, 0.0 = not trusted |
| `valid` | Whether the reading is usable | false if sensor failed |
| `allowNormalUpdate` | Whether this window can update normal baseline | false for known suspicious events |

The core engine only needs this packet:

```cpp
CAADFeatures features = mySensorModule.update(sensorReading);
CAADDecision decision = gateCore.update(features, context);
```

## 2. Standard development steps

To add a new sensor scenario:

1. Decide what raw sensor value comes in.
2. Divide data into windows if the sensor is fast.
3. Calculate lightweight features.
4. Fill a `CAADFeatures` packet.
5. Pass the packet to `CAADGateCore`.
6. Read the `CAADDecision` output.
7. Connect the output to ML, alerting, communication, or sleep.

```text
Raw sensor data
      ↓
Custom sensor module
      ↓
CAADFeatures
      ↓
CAADGateCore
      ↓
CAADDecision
      ↓
ML / alert / communication / save processing
```

## 3. Use the template files

Start by copying these files:

```text
src/modules/CAADCustomGateTemplate.h
src/modules/CAADCustomGateTemplate.cpp
```

Rename them for your sensor. Examples:

```text
CAADGasGate.h / CAADGasGate.cpp
CAADVibrationGate.h / CAADVibrationGate.cpp
CAADWaterLevelGate.h / CAADWaterLevelGate.cpp
```

Then rename the class from `CAADCustomGateTemplate` to your new class name.

## 4. Beginner-friendly example

Imagine you are adding a gas sensor.

The gas sensor gives one value:

```cpp
float gasValue = readGasSensor();
```

The module calculates:

```text
level          = current gas value
rateOfChange   = current gas value - previous gas value
variation      = short-term instability
peak           = highest recent gas value
duration       = repeated abnormal trend evidence
```

Then it sends this to the core:

```cpp
CAADFeatures features = gasGate.update(gasValue, millis());
CAADDecision decision = gateCore.update(features, context);
```

If the gate opens:

```cpp
if (decision.gateOpen) {
    sendAlert();
    publishToCloud();
}
```

If the gate is closed:

```cpp
else {
    // Normal or low-relevance data.
    // Avoid expensive processing.
}
```

## 5. Important rule: safe normal update

The normal baseline should not learn abnormal events as normal.

CAAD-Gate Core already updates the normal model only when the gate is closed. But if your application already knows a window is suspicious, set:

```cpp
features.allowNormalUpdate = false;
```

Example:

```cpp
if (sensorErrorDetected || knownDangerousSpike) {
    features.allowNormalUpdate = false;
}
```

## 6. How to tune a new module

Start with safe settings:

```cpp
CAADConfig config;
config.warmupWindows = 20;
config.learningRate = 0.01f;
config.openThreshold = 3.0f;
config.closeThresholdRatio = 0.65f;
```

Then tune:

| Need | Change |
|---|---|
| Gate opens too often | Increase `openThreshold` |
| Gate misses events | Decrease `openThreshold` |
| Baseline adapts too slowly | Increase `learningRate` slightly |
| Baseline adapts too quickly | Decrease `learningRate` |
| Gate flickers open/closed | Lower `closeThresholdRatio` or increase close windows |

## 7. What to show in a demo

For any new sensor, show these values on Serial Monitor, display, or dashboard:

```text
Sensor value
Normal baseline
Deviation / score
Adaptive threshold
Gate state: WARMUP / CLOSED / OPEN
Processing saved %
Reason
```

## 8. Best explanation for judges

> CAAD-Gate is reusable because every sensor module converts raw data into the same feature packet. The common core engine then learns normal behaviour, applies adaptive and context-aware decision logic, and outputs whether the gate should open or close.


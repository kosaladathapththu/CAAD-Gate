# CAAD-Gate Module Reference

## 1. CAADGateCore

The core decision engine.

Main methods:

```cpp
void begin();
void begin(const CAADConfig& config);
void reset();
CAADDecision update(const CAADFeatures& features);
CAADDecision update(const CAADFeatures& features, const CAADContext& context);
```

Use this in every CAAD-Gate product.

---

## 2. CAADEnvironmentGate

Converts scalar readings to CAADFeatures.

Use for:

- temperature
- gas
- humidity
- air quality
- machine condition values

Main method:

```cpp
CAADFeatures update(float value, uint32_t timestampMs = 0);
CAADFeatures updateWithContext(float value, float contextImportance, uint32_t timestampMs = 0);
```

---

## 3. CAADMotionGate

Converts accelerometer data to CAADFeatures.

Use for:

- eldercare motion
- fall-candidate forwarding
- vibration/anomaly monitoring

Main method:

```cpp
CAADFeatures update(float ax, float ay, float az, uint32_t timestampMs = 0);
CAADFeatures updateWithContext(float ax, float ay, float az, float contextImportance, uint32_t timestampMs = 0);
```

---

## 4. CAADSoundGate

Converts audio frame energy or raw samples to CAADFeatures.

Use for:

- microphone frame gate
- sound awareness
- pre-filtering before sound recognition

Main methods:

```cpp
CAADFeatures updateEnergy(float frameEnergy, uint32_t timestampMs = 0);
CAADFeatures updateEnergyWithContext(float frameEnergy, float contextImportance, uint32_t timestampMs = 0);
CAADFeatures updateFrame(const int16_t* samples, uint16_t length, uint32_t timestampMs = 0);
CAADFeatures updateFrameWithContext(const int16_t* samples, uint16_t length, float contextImportance, uint32_t timestampMs = 0);
```

---

## 5. Recommended development order

1. Test core with environment module.
2. Test motion module with accelerometer.
3. Integrate sound module with I2S microphone.
4. Add dashboard or serial CSV logging.
5. Add product-specific context rules.

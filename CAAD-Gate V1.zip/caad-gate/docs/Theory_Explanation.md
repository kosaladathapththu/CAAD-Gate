# CAAD-Gate Core Theory Explanation

## 1. The core question

CAAD-Gate asks one simple question for every sensor window:

> Is this data worth processing now?

If the data is normal, the gate stays closed. If the data is abnormal, active, fast-changing, persistent, or contextually important, the gate opens.

---

## 2. Normal behaviour learning

The core learns normal behaviour using lightweight running statistics.

It stores:

- normal mean
- normal deviation
- number of learned windows

During warmup, the system learns its first baseline. After warmup, it updates slowly only when the gate is closed.

This prevents abnormal data from being learned as normal.

---

## 3. Relevance score

The core calculates multiple scores:

| Score | Meaning |
|---|---|
| Deviation | How far the current level is from normal |
| Change | How fast the signal changed |
| Variation | How unstable the current window is |
| Peak | Whether there is a strong peak |
| Duration | Whether the event persists |
| Context | Whether application context says it is important |

These are combined into one score.

```text
relevanceScore = weighted sum of all scores
```

---

## 4. Adaptive threshold

The core uses an adaptive threshold:

```text
adaptiveThreshold = openThreshold × contextFactor
```

Context factor changes based on battery, CPU, memory, urgency, sensitivity, and alert mode.

---

## 5. Hysteresis

The gate uses two boundaries:

```text
openThreshold  = higher boundary
closeThreshold = lower boundary
```

This prevents the gate from flickering open and closed.

---

## 6. Output decision

For each update, the core returns:

- gate open or closed
- state text
- relevance score
- adaptive threshold
- normal mean
- normal deviation
- reason code
- processing reduction percentage

This makes it useful for debugging, demos, dashboards, and product development.

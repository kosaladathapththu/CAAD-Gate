/*
  ESP32 Eldercare Motion Node Example
  -----------------------------------
  Demonstrates CAAD-Gate with accelerometer-style motion values.

  Important safety note:
  This example forwards fall-candidate windows. It does not medically confirm a fall.
  A real eldercare product needs more validation, reliability testing, and alert design.

  Replace readAccelerometerG() with your ADXL/MPU/IMU library function.
*/

#include <CAADGateCore.h>
#include <modules/CAADMotionGate.h>

CAADGateCore gateCore;
CAADMotionGate motionGate;
CAADContext context;

// Demo variables for simulated motion. Replace with real accelerometer reads.
float simT = 0.0f;

void readAccelerometerG(float &ax, float &ay, float &az) {
  // Basic simulated movement around 1g.
  simT += 0.1f;
  ax = 0.03f * sin(simT);
  ay = 0.03f * cos(simT * 0.7f);
  az = 1.0f + 0.03f * sin(simT * 1.4f);

  // Every ~12 seconds simulate a sudden movement spike for demo.
  if ((millis() / 12000) % 2 == 1 && (millis() % 12000) < 800) {
    ax += 1.7f;
    ay += 0.8f;
    az += 1.2f;
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  CAADConfig coreConfig;
  coreConfig.warmupWindows = 25;
  coreConfig.learningRate = 0.01f;
  coreConfig.openThreshold = 3.2f;
  coreConfig.closeThresholdRatio = 0.65f;
  gateCore.begin(coreConfig);

  CAADMotionConfig motionConfig;
  motionConfig.stillnessJerkThreshold = 0.08f;
  motionConfig.strongImpactMagnitude = 2.2f;
  motionConfig.stillnessWindow = 8;
  motionGate.begin(motionConfig);

  // Eldercare use case can be more sensitive.
  context.sensitivity = 0.25f;
  context.urgency = 0.20f;
  context.batteryPercent = 100.0f;

  Serial.println("CAAD-Gate Eldercare Motion Node Started");
  Serial.println("Normal movement -> gate closed | Sudden motion -> gate open");
}

void loop() {
  float ax, ay, az;
  readAccelerometerG(ax, ay, az);

  CAADFeatures features = motionGate.update(ax, ay, az, millis());
  CAADDecision decision = gateCore.update(features, context);

  Serial.print("Mag: ");
  Serial.print(motionGate.getLastMagnitude(), 3);
  Serial.print("g | Jerk: ");
  Serial.print(motionGate.getLastJerk(), 3);
  Serial.print(" | Mean: ");
  Serial.print(decision.normalMean, 3);
  Serial.print(" | Score: ");
  Serial.print(decision.relevanceScore, 3);
  Serial.print(" | Th: ");
  Serial.print(decision.adaptiveThreshold, 3);
  Serial.print(" | Gate: ");
  Serial.print(CAADGateCore::stateToText(decision.state));
  Serial.print(" | Saved: ");
  Serial.print(decision.processingReductionPercent, 1);
  Serial.print("% | Reason: ");
  Serial.println(CAADGateCore::reasonToText(decision.reasonCode));

  if (decision.gateOpen) {
    // Place fall-candidate verification or alert logic here.
    // Example: check stillness/posture and then send alert.
  }

  delay(100);
}

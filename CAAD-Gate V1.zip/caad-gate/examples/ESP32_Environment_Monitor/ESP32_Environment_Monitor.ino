/*
  ESP32 Environment Monitor Example
  ---------------------------------
  Demonstrates CAAD-Gate with a scalar environment value.

  Demo idea:
  - During warmup, the device learns normal value.
  - Stable values keep the gate closed.
  - A sudden temperature/gas/environment change opens the gate.

  Hardware notes:
  - This example uses analogRead() so it can run without a specific sensor library.
  - Replace readEnvironmentValue() with your real sensor function.

  Serial Monitor baud: 115200
*/

#include <CAADGateCore.h>
#include <modules/CAADEnvironmentGate.h>

CAADGateCore gateCore;
CAADEnvironmentGate environmentGate;
CAADContext context;

// ESP32 ADC input pin. Change according to your board/sensor.
const int SENSOR_PIN = 34;

float readEnvironmentValue() {
  // Simple demo conversion from ADC to a pseudo temperature-like value.
  // Replace this with real sensor reading, e.g., DHT/BME/DS18B20/gas sensor.
  int raw = analogRead(SENSOR_PIN);
  float value = (raw / 4095.0f) * 100.0f;
  return value;
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  CAADConfig coreConfig;
  coreConfig.warmupWindows = 20;
  coreConfig.learningRate = 0.01f;
  coreConfig.openThreshold = 3.0f;
  coreConfig.closeThresholdRatio = 0.65f;
  gateCore.begin(coreConfig);

  CAADEnvironmentConfig envConfig;
  envConfig.significantChange = 0.40f;
  envConfig.persistenceWindow = 5;
  environmentGate.begin(envConfig);

  context.batteryPercent = 100.0f;
  context.sensitivity = 0.15f;
  context.urgency = 0.0f;
  context.lowPowerMode = false;

  Serial.println("CAAD-Gate Environment Monitor Started");
  Serial.println("Normal -> gate closed | Sudden change -> gate open");
}

void loop() {
  float sensorValue = readEnvironmentValue();

  CAADFeatures features = environmentGate.update(sensorValue, millis());
  CAADDecision decision = gateCore.update(features, context);

  Serial.print("Value: ");
  Serial.print(sensorValue, 3);
  Serial.print(" | Mean: ");
  Serial.print(decision.normalMean, 3);
  Serial.print(" | Dev: ");
  Serial.print(decision.normalDeviation, 3);
  Serial.print(" | Score: ");
  Serial.print(decision.relevanceScore, 3);
  Serial.print(" | Th: ");
  Serial.print(decision.adaptiveThreshold, 3);
  Serial.print(" | Gate: ");
  Serial.print(CAADGateCore::stateToText(decision.state));
  Serial.print(" | Saved: ");
  Serial.print(decision.processingReductionPercent, 1);
  Serial.print("% | Reason: ");
  Serial.println(CAADGateCore::reasonToText(decision.reasonCode));

  if (decision.gateOpen) {
    // Place alert/cloud/ML code here.
    // Example: sendAlert(sensorValue);
  }

  delay(500);
}

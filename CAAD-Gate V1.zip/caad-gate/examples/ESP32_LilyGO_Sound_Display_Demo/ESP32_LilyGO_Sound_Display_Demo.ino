/*
  CAAD-Gate LilyGO Sound Display Demo
  -----------------------------------
  Purpose:
  Demonstrates CAAD-Gate on an ESP32/LilyGO display board using one I2S mic.

  What judges should see:
      Quiet background -> Gate CLOSED -> processing saved
      Clap/knock/alarm -> Gate OPEN   -> event forwarded
      Quiet again      -> Gate CLOSED -> processing saved again

  Hardware:
      - LILYGO ESP32 / ESP32-S3 display board
      - INMP441 I2S microphone

  Recommended INMP441 wiring:
      INMP441 VDD -> 3V3
      INMP441 GND -> GND
      INMP441 SCK -> GPIO10  (BCLK)
      INMP441 WS  -> GPIO11  (LRCLK)
      INMP441 SD  -> GPIO4   (DATA)
      INMP441 L/R -> GND

  Required Arduino libraries:
      - TFT_eSPI configured for your exact LILYGO board
      - CAAD-Gate library installed in Arduino/libraries

  Note:
  This demo uses CAAD-Gate as the pre-ML decision layer. It does not run full
  MFCC/MFBE sound classification. When gate opens, that is where recognition,
  alerting, or communication would be activated.
*/

#include <Arduino.h>
#include "driver/i2s.h"
#include <TFT_eSPI.h>

#include <CAADGateCore.h>
#include <modules/CAADSoundGate.h>

// ------------------------------------------------------------
// I2S microphone settings
// ------------------------------------------------------------
#define SAMPLE_RATE     16000
#define FRAME_SIZE      512

#define MIC_BCLK_PIN    10
#define MIC_WS_PIN      11
#define MIC_SD_PIN      4

// INMP441 gives 24-bit audio inside 32-bit words.
// This shift creates an int16-style sample for the CAADSoundGate.
#define SAMPLE_SHIFT    14

// Optional LED for gate-open indication. Use -1 if not connected.
#define GATE_LED_PIN    -1

// ------------------------------------------------------------
// CAAD-Gate objects
// ------------------------------------------------------------
CAADGateCore gateCore;
CAADSoundGate soundGate;
CAADContext context;

TFT_eSPI tft = TFT_eSPI();

int32_t i2sBuffer32[FRAME_SIZE];
int16_t frame16[FRAME_SIZE];

unsigned long lastDisplayMs = 0;
const unsigned long DISPLAY_UPDATE_MS = 150;

// ------------------------------------------------------------
// Helpers
// ------------------------------------------------------------
float clampFloat(float v, float low, float high) {
  if (v < low) return low;
  if (v > high) return high;
  return v;
}

int16_t i2sSampleToInt16(int32_t raw) {
  int32_t shifted = raw >> SAMPLE_SHIFT;
  if (shifted > 32767) shifted = 32767;
  if (shifted < -32768) shifted = -32768;
  return (int16_t)shifted;
}

void drawBar(int x, int y, int w, int h, float value, float maxValue, uint16_t color) {
  if (maxValue <= 0.0f) maxValue = 1.0f;
  int fill = (int)(w * clampFloat(value / maxValue, 0.0f, 1.0f));

  tft.drawRect(x, y, w, h, TFT_DARKGREY);
  tft.fillRect(x + 1, y + 1, w - 2, h - 2, TFT_BLACK);
  tft.fillRect(x + 1, y + 1, fill, h - 2, color);
}

void drawDashboard(const CAADDecision& decision) {
  unsigned long now = millis();
  if (now - lastDisplayMs < DISPLAY_UPDATE_MS) return;
  lastDisplayMs = now;

  float energy = soundGate.getLastEnergy();
  float baseline = decision.normalMean;
  float threshold = decision.adaptiveThreshold;
  float score = decision.relevanceScore;
  float saved = decision.processingReductionPercent;

  float barMax = threshold * 2.0f;
  if (energy > barMax) barMax = energy * 1.2f;
  if (barMax < 1.0f) barMax = 1.0f;

  uint16_t statusColor = TFT_GREEN;
  const char* statusText = "CLOSED";
  const char* actionText = "Save processing";

  if (decision.state == CAAD_GATE_WARMUP) {
    statusColor = TFT_YELLOW;
    statusText = "WARMUP";
    actionText = "Learning normal";
  } else if (decision.gateOpen) {
    statusColor = TFT_RED;
    statusText = "OPEN";
    actionText = "Forward event";
  }

  tft.fillScreen(TFT_BLACK);

  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawString("CAAD-Gate Sound Demo", 8, 6, 4);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("ESP32 / LilyGO adaptive gate", 8, 36, 2);

  tft.fillRoundRect(8, 60, 155, 50, 8, statusColor);
  tft.setTextColor(TFT_BLACK, statusColor);
  tft.drawString("GATE", 18, 66, 2);
  tft.drawString(statusText, 18, 82, 4);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString(actionText, 175, 76, 4);

  tft.drawString("Energy", 8, 126, 2);
  tft.drawFloat(energy, 2, 110, 126, 2);
  drawBar(190, 128, 120, 12, energy, barMax, TFT_CYAN);

  tft.drawString("Baseline", 8, 152, 2);
  tft.drawFloat(baseline, 2, 110, 152, 2);
  drawBar(190, 154, 120, 12, baseline, barMax, TFT_BLUE);

  tft.drawString("Threshold", 8, 178, 2);
  tft.drawFloat(threshold, 2, 110, 178, 2);
  drawBar(190, 180, 120, 12, threshold, barMax, TFT_ORANGE);

  tft.drawString("Score", 8, 204, 2);
  tft.drawFloat(score, 2, 110, 204, 2);

  tft.drawString("Saved", 8, 230, 2);
  tft.drawFloat(saved, 1, 110, 230, 2);
  tft.drawString("%", 162, 230, 2);

  tft.setTextColor(TFT_LIGHTGREY, TFT_BLACK);
  tft.drawString("Reason:", 8, 256, 2);
  tft.setTextColor(decision.gateOpen ? TFT_RED : TFT_GREEN, TFT_BLACK);
  String reason = CAADGateCore::reasonToText(decision.reasonCode);
  tft.drawString(reason.substring(0, 42), 8, 276, 2);
}

// ------------------------------------------------------------
// I2S setup
// ------------------------------------------------------------
void setupI2SMic() {
  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT,
    .channel_format = I2S_CHANNEL_FMT_ONLY_LEFT,
    .communication_format = I2S_COMM_FORMAT_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 4,
    .dma_buf_len = FRAME_SIZE,
    .use_apll = false
  };

  i2s_pin_config_t pins = {
    .bck_io_num = MIC_BCLK_PIN,
    .ws_io_num = MIC_WS_PIN,
    .data_out_num = I2S_PIN_NO_CHANGE,
    .data_in_num = MIC_SD_PIN
  };

  esp_err_t err = i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL);
  if (err != ESP_OK) {
    Serial.print("i2s_driver_install failed: ");
    Serial.println(err);
  }

  err = i2s_set_pin(I2S_NUM_0, &pins);
  if (err != ESP_OK) {
    Serial.print("i2s_set_pin failed: ");
    Serial.println(err);
  }

  i2s_zero_dma_buffer(I2S_NUM_0);
}

// ------------------------------------------------------------
// Arduino setup / loop
// ------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(500);

  if (GATE_LED_PIN >= 0) {
    pinMode(GATE_LED_PIN, OUTPUT);
    digitalWrite(GATE_LED_PIN, LOW);
  }

  // CAAD-Gate core configuration.
  CAADConfig coreConfig;
  coreConfig.warmupWindows = 50;
  coreConfig.learningRate = 0.01f;
  coreConfig.openThreshold = 3.0f;
  coreConfig.closeThresholdRatio = 0.65f;
  coreConfig.deviationWeight = 1.0f;
  coreConfig.changeWeight = 0.3f;
  coreConfig.peakWeight = 0.25f;
  gateCore.begin(coreConfig);

  // Sound feature extraction configuration.
  CAADSoundConfig soundConfig;
  soundConfig.preEmphasisAlpha = 0.97f;
  soundConfig.significantEnergyChange = 500.0f;
  soundConfig.persistenceWindow = 5;
  soundGate.begin(soundConfig);

  // Context: normal demo mode.
  context.batteryPercent = 100.0f;
  context.lowPowerMode = false;
  context.sensitivity = 0.10f;
  context.urgency = 0.0f;
  context.alertMode = false;

  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.drawString("Starting CAAD-Gate...", 10, 20, 4);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("Learning background sound", 10, 60, 2);

  setupI2SMic();

  Serial.println("CAAD-Gate LilyGO Sound Display Demo");
  Serial.println("energy,baseline,threshold,score,gate,saved,reason");
}

void loop() {
  size_t bytesRead = 0;
  esp_err_t err = i2s_read(I2S_NUM_0, i2sBuffer32, sizeof(i2sBuffer32), &bytesRead, portMAX_DELAY);
  if (err != ESP_OK || bytesRead == 0) {
    return;
  }

  int samplesRead = bytesRead / sizeof(int32_t);
  if (samplesRead > FRAME_SIZE) samplesRead = FRAME_SIZE;

  for (int i = 0; i < samplesRead; i++) {
    frame16[i] = i2sSampleToInt16(i2sBuffer32[i]);
  }

  CAADFeatures features = soundGate.updateFrame(frame16, samplesRead, millis());
  CAADDecision decision = gateCore.update(features, context);

  if (GATE_LED_PIN >= 0) {
    digitalWrite(GATE_LED_PIN, decision.gateOpen ? HIGH : LOW);
  }

  Serial.print(soundGate.getLastEnergy(), 2); Serial.print(",");
  Serial.print(decision.normalMean, 2); Serial.print(",");
  Serial.print(decision.adaptiveThreshold, 2); Serial.print(",");
  Serial.print(decision.relevanceScore, 2); Serial.print(",");
  Serial.print(decision.gateOpen ? "OPEN" : CAADGateCore::stateToText(decision.state)); Serial.print(",");
  Serial.print(decision.processingReductionPercent, 1); Serial.print(",");
  Serial.println(CAADGateCore::reasonToText(decision.reasonCode));

  drawDashboard(decision);
}

/*
  CAAD-Gate Motion / Fall-Candidate Demo
  --------------------------------------
  Purpose:
  Demonstrates how CAAD-Gate can learn normal movement and open the gate
  for abnormal motion windows.

  Safety wording:
  This demo does NOT medically confirm a fall. It forwards fall-candidate
  motion windows to alert logic or ML for further checking.

  Demo behaviour:
      Normal small movement  -> gate CLOSED
      Sudden impact motion   -> gate OPEN
      Back to normal         -> gate CLOSED

  Replace readAccelerometerG() with your real ADXL/MPU/IMU reading later.

  Serial Monitor: 115200 baud
*/

#include <Arduino.h>
#include <CAADGateCore.h>
#include <modules/CAADMotionGate.h>

#define USE_SIMULATED_MOTION 1

CAADGateCore gateCore;
CAADMotionGate motionGate;
CAADContext context;

void readAccelerometerG(float &ax, float &ay, float &az) {
#if USE_SIMULATED_MOTION
  float t = millis() / 1000.0f;

  // Normal movement around 1g total magnitude.
  ax = 0.04f * sin(t * 1.1f);
  ay = 0.04f * cos(t * 0.8f);
  az = 1.00f + 0.04f * sin(t * 1.4f);

  // Simulated abnormal motion spike every 18 seconds.
  int cycleMs = millis() % 18000;
  if (cycleMs > 9000 && cycleMs < 9800) {
    ax += 1.6f;
    ay += 1.0f;
    az += 1.3f;
  }
#else
  // Replace this with a real accelerometer library.
  // Example:
  // imu.readAcceleration(ax, ay, az);
  ax = 0.0f;
  ay = 0.0f;
  az = 1.0f;
#endif
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  CAADConfig coreConfig;
  coreConfig.warmupWindows = 30;
  coreConfig.learningRate = 0.01f;
  coreConfig.openThreshold = 3.2f;
  coreConfig.closeThresholdRatio = 0.65f;
  coreConfig.deviationWeight = 1.0f;
  coreConfig.changeWeight = 0.7f;       // motion depends strongly on sudden change
  coreConfig.peakWeight = 0.5f;
  coreConfig.durationWeight = 0.4f;
  gateCore.begin(coreConfig);

  CAADMotionConfig motionConfig;
  motionConfig.stillnessJerkThreshold = 0.08f;
  motionConfig.strongImpactMagnitude = 2.2f;
  motionConfig.stillnessWindow = 8;
  motionGate.begin(motionConfig);

  // Eldercare monitoring can be slightly more sensitive.
  context.batteryPercent = 100.0f;
  context.lowPowerMode = false;
  context.sensitivity = 0.25f;
  context.urgency = 0.20f;
  context.alertMode = true;

  Serial.println();
  Serial.println("CAAD-Gate Motion / Fall-Candidate Demo");
  Serial.println("Normal movement -> gate closed | abnormal motion -> gate open");
  Serial.println("magG,jerk,normalMean,score,threshold,gate,saved%,reason");
}

void loop() {
  float ax, ay, az;
  readAccelerometerG(ax, ay, az);

  CAADFeatures features = motionGate.update(ax, ay, az, millis());
  CAADDecision decision = gateCore.update(features, context);

  Serial.print(motionGate.getLastMagnitude(), 3); Serial.print(",");
  Serial.print(motionGate.getLastJerk(), 3); Serial.print(",");
  Serial.print(decision.normalMean, 3); Serial.print(",");
  Serial.print(decision.relevanceScore, 2); Serial.print(",");
  Serial.print(decision.adaptiveThreshold, 2); Serial.print(",");
  Serial.print(CAADGateCore::stateToText(decision.state)); Serial.print(",");
  Serial.print(decision.processingReductionPercent, 1); Serial.print(",");
  Serial.println(CAADGateCore::reasonToText(decision.reasonCode));

  if (decision.gateOpen) {
    // In a real eldercare product, do further verification here.
    // Example: check posture/stillness, then send fall-candidate alert.
  }

  delay(100);
}

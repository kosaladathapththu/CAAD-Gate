/*
  ESP32 Sound Awareness Node Example
  ----------------------------------
  Demonstrates CAAD-Gate with microphone-like frame energy.

  Hardware notes:
  - This minimal example uses analogRead() to build a small audio-like frame.
  - For a real sound recognition system, replace this with I2S microphone input.
  - CAAD-Gate should run before MFCC/MFBE/classification to reduce unnecessary processing.
*/

#include <CAADGateCore.h>
#include <modules/CAADSoundGate.h>

CAADGateCore gateCore;
CAADSoundGate soundGate;
CAADContext context;

const int MIC_PIN = 34;
const int FRAME_SIZE = 256;
int16_t frameBuffer[FRAME_SIZE];

void readAnalogMicFrame() {
  for (int i = 0; i < FRAME_SIZE; i++) {
    int raw = analogRead(MIC_PIN);          // 0 to 4095 on ESP32 ADC
    frameBuffer[i] = (int16_t)(raw - 2048); // center around 0
    delayMicroseconds(80);                 // rough demo sampling only
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  CAADConfig coreConfig;
  coreConfig.warmupWindows = 30;
  coreConfig.learningRate = 0.01f;
  coreConfig.openThreshold = 3.0f;
  coreConfig.closeThresholdRatio = 0.65f;
  gateCore.begin(coreConfig);

  CAADSoundConfig soundConfig;
  soundConfig.preEmphasisAlpha = 0.97f;
  soundConfig.significantEnergyChange = 500.0f;
  soundConfig.persistenceWindow = 5;
  soundGate.begin(soundConfig);

  context.sensitivity = 0.10f;
  context.batteryPercent = 100.0f;

  Serial.println("CAAD-Gate Sound Awareness Node Started");
  Serial.println("Background -> gate closed | Clap/knock/sound -> gate open");
}

void loop() {
  readAnalogMicFrame();

  CAADFeatures features = soundGate.updateFrame(frameBuffer, FRAME_SIZE, millis());
  CAADDecision decision = gateCore.update(features, context);

  Serial.print("Energy: ");
  Serial.print(soundGate.getLastEnergy(), 2);
  Serial.print(" | dE: ");
  Serial.print(soundGate.getLastEnergyChange(), 2);
  Serial.print(" | Mean: ");
  Serial.print(decision.normalMean, 2);
  Serial.print(" | Score: ");
  Serial.print(decision.relevanceScore, 2);
  Serial.print(" | Th: ");
  Serial.print(decision.adaptiveThreshold, 2);
  Serial.print(" | Gate: ");
  Serial.print(CAADGateCore::stateToText(decision.state));
  Serial.print(" | Saved: ");
  Serial.print(decision.processingReductionPercent, 1);
  Serial.print("% | Reason: ");
  Serial.println(CAADGateCore::reasonToText(decision.reasonCode));

  if (decision.gateOpen) {
    // Place feature extraction / MFCC / MFBE / prototype matching here.
  }
}

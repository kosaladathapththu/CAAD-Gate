/*
  CAAD-Gate Temperature / Machine Monitoring Demo
  ------------------------------------------------
  Purpose:
  Demonstrates how CAAD-Gate can learn the normal temperature behaviour
  of a device/machine and open the gate only when an abnormal rise happens.

  This example is intentionally beginner-friendly:
  - It runs with SIMULATED temperature data by default.
  - You can replace readTemperatureC() with a real sensor library later.

  Demo behaviour:
      Warmup       -> learns normal around 40 C
      Normal temp  -> gate CLOSED
      Sudden rise  -> gate OPEN
      Stable again -> gate CLOSED

  Serial Monitor: 115200 baud
*/

#include <Arduino.h>
#include <CAADGateCore.h>
#include <modules/CAADEnvironmentGate.h>

// Set to 1 for a no-sensor demo. Set to 0 and edit readTemperatureC() for a real sensor.
#define USE_SIMULATED_TEMPERATURE 1

CAADGateCore gateCore;
CAADEnvironmentGate environmentGate;
CAADContext context;

// Optional analog pin for simple sensor testing.
const int TEMP_ADC_PIN = 34;

float readTemperatureC() {
#if USE_SIMULATED_TEMPERATURE
  // Simulated machine temperature.
  // Normal region: around 40 C.
  // Every 20 seconds: simulate abnormal rise.
  float t = millis() / 1000.0f;
  float normal = 40.0f + 0.25f * sin(t * 0.7f);

  // Abnormal event between second 10 and 16 in each 25-second cycle.
  int cycleMs = millis() % 25000;
  if (cycleMs > 10000 && cycleMs < 16000) {
    return normal + 8.0f + 1.5f * sin(t * 2.0f);
  }
  return normal;
#else
  // Replace this section with your real temperature sensor reading.
  // Example options: DS18B20, DHT22, BME280, thermistor, industrial ADC.
  int raw = analogRead(TEMP_ADC_PIN);
  float voltage = (raw / 4095.0f) * 3.3f;
  float pseudoTemperature = voltage * 30.0f; // only a placeholder conversion
  return pseudoTemperature;
#endif
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  CAADConfig coreConfig;
  coreConfig.warmupWindows = 20;
  coreConfig.learningRate = 0.01f;       // slow adaptation
  coreConfig.openThreshold = 3.0f;       // lower = more sensitive, higher = stricter
  coreConfig.closeThresholdRatio = 0.65f;
  coreConfig.deviationWeight = 1.0f;
  coreConfig.changeWeight = 0.4f;
  coreConfig.variationWeight = 0.2f;
  coreConfig.peakWeight = 0.2f;
  coreConfig.durationWeight = 0.3f;
  gateCore.begin(coreConfig);

  CAADEnvironmentConfig envConfig;
  envConfig.significantChange = 0.4f;    // C difference considered meaningful
  envConfig.persistenceWindow = 5;
  environmentGate.begin(envConfig);

  // Normal machine monitoring context.
  context.batteryPercent = 100.0f;
  context.lowPowerMode = false;
  context.sensitivity = 0.10f;
  context.urgency = 0.0f;
  context.alertMode = false;

  Serial.println();
  Serial.println("CAAD-Gate Temperature Monitor Demo");
  Serial.println("Temperature learns normal -> abnormal rise opens gate");
  Serial.println("tempC,normalMean,normalDev,score,threshold,gate,saved%,reason");
}

void loop() {
  float tempC = readTemperatureC();

  CAADFeatures features = environmentGate.update(tempC, millis());
  CAADDecision decision = gateCore.update(features, context);

  Serial.print(tempC, 2); Serial.print(",");
  Serial.print(decision.normalMean, 2); Serial.print(",");
  Serial.print(decision.normalDeviation, 3); Serial.print(",");
  Serial.print(decision.relevanceScore, 2); Serial.print(",");
  Serial.print(decision.adaptiveThreshold, 2); Serial.print(",");
  Serial.print(CAADGateCore::stateToText(decision.state)); Serial.print(",");
  Serial.print(decision.processingReductionPercent, 1); Serial.print(",");
  Serial.println(CAADGateCore::reasonToText(decision.reasonCode));

  if (decision.gateOpen) {
    // In a real product, put alert/cloud/ML code here.
    // Example: sendTemperatureAlert(tempC);
  }

  delay(500);
}

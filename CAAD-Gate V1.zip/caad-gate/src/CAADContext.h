#ifndef CAAD_CONTEXT_H
#define CAAD_CONTEXT_H

/*
  CAADContext
  -----------
  Optional device/application context passed to CAADGateCore.

  CAAD-Gate is context-aware because the gate can become:
  - More sensitive during important/urgent situations.
  - More strict when battery, CPU, or memory resources are low.

  All values have safe defaults, so simple demos can call core.update(features)
  without providing a custom context.
*/

struct CAADContext {
    // Battery percentage: 0 to 100. Use 100 if unknown.
    float batteryPercent;

    // CPU load percentage: 0 to 100. Use 0 if unknown.
    float cpuLoadPercent;

    // Memory pressure percentage: 0 to 100. Use 0 if unknown.
    float memoryPressurePercent;

    // Application sensitivity: 0.0 = normal, 1.0 = highly sensitive.
    float sensitivity;

    // Urgency: 0.0 = normal, 1.0 = urgent.
    float urgency;

    // Low-power mode makes the gate stricter.
    bool lowPowerMode;

    // Alert mode makes the gate more sensitive.
    bool alertMode;

    // Set false to ignore context adjustment and keep factor close to 1.0.
    bool contextEnabled;

    CAADContext()
        : batteryPercent(100.0f),
          cpuLoadPercent(0.0f),
          memoryPressurePercent(0.0f),
          sensitivity(0.0f),
          urgency(0.0f),
          lowPowerMode(false),
          alertMode(false),
          contextEnabled(true) {}
};

#endif

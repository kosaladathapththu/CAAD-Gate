#include "CAADGateCore.h"
#include <math.h>

CAADGateCore::CAADGateCore() {
    _started = false;
    reset();
}

void CAADGateCore::begin() {
    CAADConfig defaultConfig;
    begin(defaultConfig);
}

void CAADGateCore::begin(const CAADConfig& config) {
    _config = config;
    reset();
    _started = true;
}

void CAADGateCore::reset() {
    _normal = CAADNormalModel();
    _last = CAADDecision();
    _state = CAAD_GATE_WARMUP;
    _openCandidateCount = 0;
    _closeCandidateCount = 0;
    _totalWindows = 0;
    _forwardedWindows = 0;
    _rejectedWindows = 0;
}

CAADDecision CAADGateCore::update(const CAADFeatures& features) {
    CAADContext defaultContext;
    return update(features, defaultContext);
}

CAADDecision CAADGateCore::update(const CAADFeatures& features, const CAADContext& context) {
    if (!_started) {
        begin();
    }

    _totalWindows++;

    // Invalid input must never open the gate.
    if (!features.valid) {
        _state = CAAD_GATE_CLOSED;
        _rejectedWindows++;
        _last = buildDecision(false, _state, CAAD_REASON_INVALID_INPUT,
                              0.0f, _config.openThreshold, _config.openThreshold * _config.closeThresholdRatio,
                              1.0f, features.timestampMs);
        return _last;
    }

    // Warmup stage: learn the first normal baseline and keep gate closed.
    if (!_normal.initialized || _normal.sampleCount < _config.warmupWindows) {
        updateNormalWarmup(features.level);
        _state = CAAD_GATE_WARMUP;
        _rejectedWindows++;
        _last = buildDecision(false, _state, CAAD_REASON_WARMUP_LEARNING,
                              0.0f, _config.openThreshold, _config.openThreshold * _config.closeThresholdRatio,
                              1.0f, features.timestampMs);
        return _last;
    }

    // Warmup is complete. Move from WARMUP to CLOSED before normal decision logic.
    if (_state == CAAD_GATE_WARMUP) {
        _state = CAAD_GATE_CLOSED;
        _openCandidateCount = 0;
        _closeCandidateCount = 0;
    }

    const float dev = safeDeviation();
    const float confidence = clampFloat(features.confidence, 0.0f, 1.0f);

    // Individual relevance components. They are normalized by learned normal deviation.
    float deviationScore = absFloat(features.level - _normal.mean) / dev;
    float changeScore = absFloat(features.rateOfChange) / dev;
    float variationScore = absFloat(features.variation) / dev;
    float peakScore = maxFloat(0.0f, features.peak - _normal.mean) / dev;
    float durationScore = maxFloat(0.0f, features.durationEvidence);
    float contextScore = maxFloat(0.0f, features.contextImportance);

    // Weighted score. This is the final measure of "is this window worth processing?"
    float relevanceScore =
        (_config.deviationWeight * deviationScore) +
        (_config.changeWeight * changeScore) +
        (_config.variationWeight * variationScore) +
        (_config.peakWeight * peakScore) +
        (_config.durationWeight * durationScore) +
        (_config.contextWeight * contextScore);

    relevanceScore *= confidence;

    const float contextFactor = calculateContextFactor(context);
    const float adaptiveThreshold = _config.openThreshold * contextFactor;
    const float closeThreshold = adaptiveThreshold * _config.closeThresholdRatio;

    const bool openCandidate = relevanceScore >= adaptiveThreshold;
    const bool closeCandidate = relevanceScore < closeThreshold;

    CAADReasonCode reason = CAAD_REASON_NORMAL_LOW_RELEVANCE;

    if (_state == CAAD_GATE_OPEN) {
        if (closeCandidate) {
            _closeCandidateCount++;
        } else {
            _closeCandidateCount = 0;
        }

        if (_closeCandidateCount >= _config.minConsecutiveCloseWindows) {
            _state = CAAD_GATE_CLOSED;
            _closeCandidateCount = 0;
            _openCandidateCount = 0;
            reason = CAAD_REASON_NORMAL_LOW_RELEVANCE;
        } else {
            reason = CAAD_REASON_GATE_HYSTERESIS_HOLD_OPEN;
        }
    } else {
        if (openCandidate) {
            _openCandidateCount++;
        } else {
            _openCandidateCount = 0;
        }

        if (_openCandidateCount >= _config.minConsecutiveOpenWindows) {
            _state = CAAD_GATE_OPEN;
            _openCandidateCount = 0;
            _closeCandidateCount = 0;
            reason = chooseMainReason(deviationScore, changeScore, variationScore,
                                      peakScore, durationScore, contextScore, context);
        } else {
            reason = openCandidate ? CAAD_REASON_GATE_HYSTERESIS_HOLD_CLOSED
                                   : CAAD_REASON_NORMAL_LOW_RELEVANCE;
        }
    }

    const bool gateOpen = (_state == CAAD_GATE_OPEN);

    if (gateOpen) {
        _forwardedWindows++;
    } else {
        _rejectedWindows++;

        // Safe update rule: update normal only when the gate is closed.
        // This prevents abnormal events from becoming part of the normal baseline.
        if (features.allowNormalUpdate) {
            updateNormalSlow(features.level);
        }
    }

    // Low-power/resource context can be useful as a debug reason when the gate is strict.
    if (!gateOpen && context.contextEnabled && (context.lowPowerMode || context.batteryPercent < 20.0f || context.cpuLoadPercent > 85.0f || context.memoryPressurePercent > 85.0f)) {
        reason = CAAD_REASON_RESOURCE_STRICT_MODE;
    }

    _last = buildDecision(gateOpen, _state, reason, relevanceScore,
                          adaptiveThreshold, closeThreshold, contextFactor, features.timestampMs);
    return _last;
}

CAADNormalModel CAADGateCore::getNormalModel() const {
    return _normal;
}

CAADDecision CAADGateCore::getLastDecision() const {
    return _last;
}

CAADConfig CAADGateCore::getConfig() const {
    return _config;
}

float CAADGateCore::safeDeviation() const {
    if (_normal.deviation < _config.minNormalDeviation) {
        return _config.minNormalDeviation;
    }
    return _normal.deviation;
}

float CAADGateCore::clampFloat(float value, float low, float high) const {
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

float CAADGateCore::absFloat(float value) const {
    return value < 0.0f ? -value : value;
}

float CAADGateCore::maxFloat(float a, float b) const {
    return a > b ? a : b;
}

void CAADGateCore::updateNormalWarmup(float level) {
    _normal.sampleCount++;

    if (!_normal.initialized) {
        _normal.initialized = true;
        _normal.mean = level;
        _normal.deviation = _config.minNormalDeviation;
        return;
    }

    // Cumulative update for stable warmup baseline.
    float previousMean = _normal.mean;
    float n = (float)_normal.sampleCount;
    _normal.mean = previousMean + ((level - previousMean) / n);

    // Lightweight average absolute deviation approximation.
    float currentAbsError = absFloat(level - _normal.mean);
    _normal.deviation = _normal.deviation + ((currentAbsError - _normal.deviation) / n);
    if (_normal.deviation < _config.minNormalDeviation) {
        _normal.deviation = _config.minNormalDeviation;
    }
}

void CAADGateCore::updateNormalSlow(float level) {
    const float alpha = clampFloat(_config.learningRate, 0.0f, 1.0f);
    float oldMean = _normal.mean;
    _normal.mean = (oldMean * (1.0f - alpha)) + (level * alpha);

    float absError = absFloat(level - _normal.mean);
    _normal.deviation = (_normal.deviation * (1.0f - alpha)) + (absError * alpha);
    if (_normal.deviation < _config.minNormalDeviation) {
        _normal.deviation = _config.minNormalDeviation;
    }

    _normal.sampleCount++;
}

float CAADGateCore::calculateContextFactor(const CAADContext& context) const {
    if (!context.contextEnabled) {
        return 1.0f;
    }

    float factor = 1.0f;

    // More sensitivity and urgency lower the threshold.
    factor *= (1.0f - (0.25f * clampFloat(context.sensitivity, 0.0f, 1.0f)));
    factor *= (1.0f - (0.20f * clampFloat(context.urgency, 0.0f, 1.0f)));

    if (context.alertMode) {
        factor *= 0.80f;
    }

    // Resource pressure raises the threshold to reduce processing.
    if (context.lowPowerMode) {
        factor *= 1.45f;
    }

    if (context.batteryPercent < 10.0f) {
        factor *= 1.50f;
    } else if (context.batteryPercent < 20.0f) {
        factor *= 1.25f;
    }

    if (context.cpuLoadPercent > 85.0f) {
        factor *= 1.20f;
    }

    if (context.memoryPressurePercent > 85.0f) {
        factor *= 1.20f;
    }

    return clampFloat(factor, _config.minContextFactor, _config.maxContextFactor);
}

CAADReasonCode CAADGateCore::chooseMainReason(
    float deviationScore,
    float changeScore,
    float variationScore,
    float peakScore,
    float durationScore,
    float contextScore,
    const CAADContext& context) const {

    if (context.contextEnabled && context.alertMode) {
        // Alert mode can be a supporting reason, but we still choose the strongest evidence below.
    }

    float best = deviationScore * _config.deviationWeight;
    CAADReasonCode reason = CAAD_REASON_HIGH_DEVIATION;

    float change = changeScore * _config.changeWeight;
    if (change > best) {
        best = change;
        reason = CAAD_REASON_FAST_CHANGE;
    }

    float variation = variationScore * _config.variationWeight;
    if (variation > best) {
        best = variation;
        reason = CAAD_REASON_HIGH_VARIATION;
    }

    float peak = peakScore * _config.peakWeight;
    if (peak > best) {
        best = peak;
        reason = CAAD_REASON_HIGH_PEAK;
    }

    float duration = durationScore * _config.durationWeight;
    if (duration > best) {
        best = duration;
        reason = CAAD_REASON_PERSISTENT_EVENT;
    }

    float contextImportance = contextScore * _config.contextWeight;
    if (contextImportance > best) {
        best = contextImportance;
        reason = CAAD_REASON_CONTEXT_IMPORTANT;
    }

    return reason;
}

CAADDecision CAADGateCore::buildDecision(
    bool gateOpen,
    CAADGateState state,
    CAADReasonCode reasonCode,
    float score,
    float adaptiveThreshold,
    float closeThreshold,
    float contextFactor,
    uint32_t timestampMs) const {

    CAADDecision decision;
    decision.gateOpen = gateOpen;
    decision.state = state;
    decision.reasonCode = reasonCode;
    decision.relevanceScore = score;
    decision.adaptiveThreshold = adaptiveThreshold;
    decision.closeThreshold = closeThreshold;
    decision.contextFactor = contextFactor;
    decision.normalMean = _normal.mean;
    decision.normalDeviation = safeDeviation();
    decision.totalWindows = _totalWindows;
    decision.forwardedWindows = _forwardedWindows;
    decision.rejectedWindows = _rejectedWindows;
    decision.timestampMs = timestampMs;

    if (_totalWindows > 0) {
        decision.processingReductionPercent = ((float)_rejectedWindows / (float)_totalWindows) * 100.0f;
    }

    return decision;
}

const char* CAADGateCore::stateToText(CAADGateState state) {
    switch (state) {
        case CAAD_GATE_WARMUP: return "WARMUP";
        case CAAD_GATE_CLOSED: return "CLOSED";
        case CAAD_GATE_OPEN: return "OPEN";
        default: return "UNKNOWN";
    }
}

const char* CAADGateCore::reasonToText(CAADReasonCode reason) {
    switch (reason) {
        case CAAD_REASON_NONE: return "No reason";
        case CAAD_REASON_WARMUP_LEARNING: return "Warmup: learning normal behaviour";
        case CAAD_REASON_INVALID_INPUT: return "Invalid input: safely rejected";
        case CAAD_REASON_NORMAL_LOW_RELEVANCE: return "Normal or low-relevance data";
        case CAAD_REASON_HIGH_DEVIATION: return "Gate opened: high deviation from normal";
        case CAAD_REASON_FAST_CHANGE: return "Gate opened: fast change detected";
        case CAAD_REASON_HIGH_VARIATION: return "Gate opened: high variation detected";
        case CAAD_REASON_HIGH_PEAK: return "Gate opened: high peak detected";
        case CAAD_REASON_PERSISTENT_EVENT: return "Gate opened: persistent event evidence";
        case CAAD_REASON_CONTEXT_IMPORTANT: return "Gate opened: context indicates importance";
        case CAAD_REASON_GATE_HYSTERESIS_HOLD_OPEN: return "Gate kept open by hysteresis";
        case CAAD_REASON_GATE_HYSTERESIS_HOLD_CLOSED: return "Gate kept closed until validation";
        case CAAD_REASON_RESOURCE_STRICT_MODE: return "Gate closed/strict: resource-protection mode";
        default: return "Unknown reason";
    }
}

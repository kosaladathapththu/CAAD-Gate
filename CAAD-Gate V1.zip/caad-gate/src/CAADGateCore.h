#ifndef CAAD_GATE_CORE_H
#define CAAD_GATE_CORE_H

/*
  CAADGateCore
  ------------
  Common adaptive decision engine used by all CAAD-Gate sensor modules.

  The core does NOT read sensors directly.
  Sensor modules convert raw readings into CAADFeatures, then the core decides:

      Gate Closed -> reject normal/low-relevance data and save processing
      Gate Open   -> forward useful/abnormal/contextual data to ML/alert/cloud

  This separation keeps the framework reusable across sound, environment,
  air-quality, motion, and other edge-IoT products.
*/

#include "CAADTypes.h"
#include "CAADContext.h"

class CAADGateCore {
public:
    CAADGateCore();

    // Start the core with default configuration.
    void begin();

    // Start the core with custom configuration.
    void begin(const CAADConfig& config);

    // Reset learned normal behaviour, gate state, counters, and decision state.
    void reset();

    // Update without context. Uses safe default context.
    CAADDecision update(const CAADFeatures& features);

    // Update with context. Use this for low-power mode, alert mode, sensitivity, etc.
    CAADDecision update(const CAADFeatures& features, const CAADContext& context);

    // Read-only helpers.
    CAADNormalModel getNormalModel() const;
    CAADDecision getLastDecision() const;
    CAADConfig getConfig() const;

    // Human-readable text for debugging/serial monitor/demo dashboard.
    static const char* stateToText(CAADGateState state);
    static const char* reasonToText(CAADReasonCode reason);

private:
    CAADConfig _config;
    CAADNormalModel _normal;
    CAADDecision _last;
    CAADGateState _state;

    uint8_t _openCandidateCount;
    uint8_t _closeCandidateCount;

    uint32_t _totalWindows;
    uint32_t _forwardedWindows;
    uint32_t _rejectedWindows;

    bool _started;

    float safeDeviation() const;
    float clampFloat(float value, float low, float high) const;
    float absFloat(float value) const;
    float maxFloat(float a, float b) const;

    void updateNormalWarmup(float level);
    void updateNormalSlow(float level);

    float calculateContextFactor(const CAADContext& context) const;
    CAADReasonCode chooseMainReason(
        float deviationScore,
        float changeScore,
        float variationScore,
        float peakScore,
        float durationScore,
        float contextScore,
        const CAADContext& context) const;

    CAADDecision buildDecision(
        bool gateOpen,
        CAADGateState state,
        CAADReasonCode reasonCode,
        float score,
        float adaptiveThreshold,
        float closeThreshold,
        float contextFactor,
        uint32_t timestampMs) const;
};

#endif

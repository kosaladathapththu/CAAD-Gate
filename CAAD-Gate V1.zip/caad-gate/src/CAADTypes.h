#ifndef CAAD_TYPES_H
#define CAAD_TYPES_H

/*
  CAAD-Gate Framework V1
  ----------------------
  This file contains the common data structures used by the whole framework.

  Design idea:
  - Sensor-specific modules convert raw data into CAADFeatures.
  - CAADGateCore reads CAADFeatures and returns CAADDecision.
  - The application decides what to do when the gate is open or closed.

  This file is intentionally lightweight so it can run on ESP32-class devices.
*/

#include <stdint.h>

// Main gate state. WARMUP means the gate is learning the initial normal baseline.
enum CAADGateState {
    CAAD_GATE_WARMUP = 0,
    CAAD_GATE_CLOSED = 1,
    CAAD_GATE_OPEN = 2
};

// Human-readable reason category for the latest decision.
enum CAADReasonCode {
    CAAD_REASON_NONE = 0,
    CAAD_REASON_WARMUP_LEARNING,
    CAAD_REASON_INVALID_INPUT,
    CAAD_REASON_NORMAL_LOW_RELEVANCE,
    CAAD_REASON_HIGH_DEVIATION,
    CAAD_REASON_FAST_CHANGE,
    CAAD_REASON_HIGH_VARIATION,
    CAAD_REASON_HIGH_PEAK,
    CAAD_REASON_PERSISTENT_EVENT,
    CAAD_REASON_CONTEXT_IMPORTANT,
    CAAD_REASON_GATE_HYSTERESIS_HOLD_OPEN,
    CAAD_REASON_GATE_HYSTERESIS_HOLD_CLOSED,
    CAAD_REASON_RESOURCE_STRICT_MODE
};

// Lightweight feature packet sent from sensor modules to the core.
struct CAADFeatures {
    // Main sensor level.
    // Examples: sound frame energy, temperature, gas value, acceleration magnitude.
    float level;

    // Instability inside the current window.
    // Examples: energy variation, temperature standard deviation, motion instability.
    float variation;

    // Speed of change from the previous window.
    // Examples: temperature delta, energy delta, accelerometer jerk.
    float rateOfChange;

    // Maximum important value in the current window.
    // Examples: sound peak, acceleration peak, maximum environmental reading.
    float peak;

    // Evidence that the event is not a single random spike.
    // Keep this low for normal data and increase it for persistent evidence.
    float durationEvidence;

    // Application-level importance from the sensor/application layer.
    // Range suggestion: 0.0 to 1.0, but the core safely accepts larger values too.
    float contextImportance;

    // Feature reliability. 1.0 = trusted, 0.0 = not trusted.
    float confidence;

    // Set false when sensor data is missing/corrupted. The core safely rejects invalid input.
    bool valid;

    // Set false when the current window is suspicious and should NOT update normal baseline.
    bool allowNormalUpdate;

    // Optional timestamp from the application. 0 is allowed.
    uint32_t timestampMs;

    CAADFeatures()
        : level(0.0f),
          variation(0.0f),
          rateOfChange(0.0f),
          peak(0.0f),
          durationEvidence(0.0f),
          contextImportance(0.0f),
          confidence(1.0f),
          valid(true),
          allowNormalUpdate(true),
          timestampMs(0) {}
};

// Configuration values used by the core.
struct CAADConfig {
    // Initial baseline learning. During warmup the gate stays closed.
    uint16_t warmupWindows;

    // Normal model update speed after warmup.
    // Small value = slow adaptation, stable baseline.
    // Large value = fast adaptation, but higher risk of learning abnormal events.
    float learningRate;

    // Base threshold for opening the gate. Final threshold is adjusted by context.
    float openThreshold;

    // Closing threshold = adaptiveThreshold * closeThresholdRatio.
    // Must be lower than open threshold to reduce flickering.
    float closeThresholdRatio;

    // Minimum deviation value to avoid division by zero.
    float minNormalDeviation;

    // Consecutive window validation.
    uint8_t minConsecutiveOpenWindows;
    uint8_t minConsecutiveCloseWindows;

    // Relevance-score weights.
    float deviationWeight;
    float changeWeight;
    float variationWeight;
    float peakWeight;
    float durationWeight;
    float contextWeight;

    // Clamp limits for context factor.
    // Lower context factor makes gate more sensitive.
    // Higher context factor makes gate stricter.
    float minContextFactor;
    float maxContextFactor;

    CAADConfig()
        : warmupWindows(20),
          learningRate(0.01f),
          openThreshold(3.0f),
          closeThresholdRatio(0.65f),
          minNormalDeviation(0.0001f),
          minConsecutiveOpenWindows(1),
          minConsecutiveCloseWindows(2),
          deviationWeight(1.00f),
          changeWeight(0.40f),
          variationWeight(0.25f),
          peakWeight(0.35f),
          durationWeight(0.30f),
          contextWeight(0.50f),
          minContextFactor(0.35f),
          maxContextFactor(3.00f) {}
};

// Lightweight normal model maintained by the core.
struct CAADNormalModel {
    bool initialized;
    uint32_t sampleCount;
    float mean;
    float deviation;

    CAADNormalModel()
        : initialized(false), sampleCount(0), mean(0.0f), deviation(0.0f) {}
};

// Output decision returned by CAADGateCore.update(...).
struct CAADDecision {
    bool gateOpen;
    CAADGateState state;
    CAADReasonCode reasonCode;

    float relevanceScore;
    float adaptiveThreshold;
    float closeThreshold;
    float contextFactor;

    float normalMean;
    float normalDeviation;

    uint32_t totalWindows;
    uint32_t forwardedWindows;
    uint32_t rejectedWindows;
    float processingReductionPercent;

    uint32_t timestampMs;

    CAADDecision()
        : gateOpen(false),
          state(CAAD_GATE_WARMUP),
          reasonCode(CAAD_REASON_NONE),
          relevanceScore(0.0f),
          adaptiveThreshold(0.0f),
          closeThreshold(0.0f),
          contextFactor(1.0f),
          normalMean(0.0f),
          normalDeviation(0.0f),
          totalWindows(0),
          forwardedWindows(0),
          rejectedWindows(0),
          processingReductionPercent(0.0f),
          timestampMs(0) {}
};

#endif

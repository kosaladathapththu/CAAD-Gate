#include "CAADCustomGateTemplate.h"

CAADCustomGateTemplate::CAADCustomGateTemplate() {
    begin();
}

void CAADCustomGateTemplate::begin() {
    CAADCustomGateConfig defaultConfig;
    begin(defaultConfig);
}

void CAADCustomGateTemplate::begin(const CAADCustomGateConfig& config) {
    _config = config;
    reset();
}

void CAADCustomGateTemplate::reset() {
    _hasLast = false;
    _lastValue = 0.0f;
    _lastRateOfChange = 0.0f;
    _localMean = 0.0f;
    _localVariation = 0.0f;
    _recentPeak = 0.0f;
    _persistenceCount = 0;
}

CAADFeatures CAADCustomGateTemplate::update(float sensorValue, uint32_t timestampMs) {
    return updateWithContext(sensorValue, _config.defaultContextImportance, timestampMs);
}

CAADFeatures CAADCustomGateTemplate::updateWithContext(float sensorValue, float contextImportance, uint32_t timestampMs) {
    CAADFeatures features;
    features.valid = true;
    features.timestampMs = timestampMs;

    // ------------------------------------------------------------
    // 1. LEVEL
    // ------------------------------------------------------------
    // Level is the main value of this sensor.
    // Example: temperature C, gas ADC value, vibration level, water level.
    features.level = sensorValue;

    // ------------------------------------------------------------
    // 2. RATE OF CHANGE
    // ------------------------------------------------------------
    // Rate of change shows how fast the sensor value moved since last window.
    // Example: temperature suddenly rising, gas value suddenly increasing.
    float rate = 0.0f;
    if (_hasLast) {
        rate = sensorValue - _lastValue;
    }
    _lastRateOfChange = rate;
    features.rateOfChange = rate;

    // ------------------------------------------------------------
    // 3. LOCAL VARIATION
    // ------------------------------------------------------------
    // This estimates short-term instability. The main normal model is still
    // handled by CAADGateCore. This value is just a lightweight feature.
    if (!_hasLast) {
        _localMean = sensorValue;
        _localVariation = 0.0f;
        _recentPeak = sensorValue;
    } else {
        const float alpha = clampFloat(_config.localSmoothing, 0.0f, 1.0f);
        _localMean = (_localMean * (1.0f - alpha)) + (sensorValue * alpha);
        _localVariation = (_localVariation * (1.0f - alpha)) + (absFloat(sensorValue - _localMean) * alpha);
        _recentPeak = maxFloat(_recentPeak * 0.95f, sensorValue);
    }
    features.variation = _localVariation;

    // ------------------------------------------------------------
    // 4. PEAK
    // ------------------------------------------------------------
    // Peak tells the core whether there was a high recent value.
    features.peak = _recentPeak;

    // ------------------------------------------------------------
    // 5. DURATION EVIDENCE
    // ------------------------------------------------------------
    // If meaningful changes continue for several windows, duration evidence grows.
    // This helps avoid reacting to one random sensor spike.
    if (absFloat(rate) >= _config.significantChange) {
        if (_persistenceCount < _config.persistenceWindow) {
            _persistenceCount++;
        }
    } else {
        if (_persistenceCount > 0) {
            _persistenceCount--;
        }
    }

    features.durationEvidence = (_config.persistenceWindow == 0)
        ? 0.0f
        : ((float)_persistenceCount / (float)_config.persistenceWindow);

    // ------------------------------------------------------------
    // 6. CONTEXT IMPORTANCE / CONFIDENCE / SAFE UPDATE FLAG
    // ------------------------------------------------------------
    features.contextImportance = contextImportance;
    features.confidence = 1.0f;

    // Usually true. The core will update normal model only when the gate is closed.
    // Set false from an application if you already know this reading is suspicious.
    features.allowNormalUpdate = true;

    _lastValue = sensorValue;
    _hasLast = true;
    return features;
}

float CAADCustomGateTemplate::getLastValue() const {
    return _lastValue;
}

float CAADCustomGateTemplate::getLastRateOfChange() const {
    return _lastRateOfChange;
}

float CAADCustomGateTemplate::getLocalMean() const {
    return _localMean;
}

float CAADCustomGateTemplate::getLocalVariation() const {
    return _localVariation;
}

float CAADCustomGateTemplate::absFloat(float value) const {
    return value < 0.0f ? -value : value;
}

float CAADCustomGateTemplate::maxFloat(float a, float b) const {
    return a > b ? a : b;
}

float CAADCustomGateTemplate::clampFloat(float value, float low, float high) const {
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

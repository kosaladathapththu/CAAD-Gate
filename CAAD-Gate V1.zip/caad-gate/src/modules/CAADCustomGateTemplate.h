#ifndef CAAD_CUSTOM_GATE_TEMPLATE_H
#define CAAD_CUSTOM_GATE_TEMPLATE_H

/*
  CAADCustomGateTemplate
  ----------------------
  This file is a starter template for adding a NEW sensor scenario to
  the CAAD-Gate framework.

  Why this exists:
  - CAAD-Gate Core is sensor-independent.
  - Every new sensor must convert its raw readings into CAADFeatures.
  - This template shows the standard way to do that.

  Example new scenarios:
  - gas sensor / smoke sensor
  - vibration sensor
  - water level sensor
  - light sensor
  - soil moisture sensor
  - heart-rate / wearable signal

  IMPORTANT:
  This template does NOT make the final decision.
  It only extracts simple features and passes them to CAADGateCore.
*/

#include "../CAADTypes.h"

// Configuration for a generic single-value sensor.
// A developer can tune these values for their own sensor.
struct CAADCustomGateConfig {
    // How much change is considered meaningful for this sensor?
    // Example: temperature 0.5 C, gas value 20 ADC units, water level 2 cm.
    float significantChange;

    // How many repeated meaningful changes should increase duration evidence?
    uint8_t persistenceWindow;

    // Local smoothing speed used only for feature estimation.
    // This is not the main normal model; the core handles that.
    float localSmoothing;

    // Optional scenario importance added to the CAADFeatures packet.
    float defaultContextImportance;

    CAADCustomGateConfig()
        : significantChange(1.0f),
          persistenceWindow(5),
          localSmoothing(0.05f),
          defaultContextImportance(0.0f) {}
};

class CAADCustomGateTemplate {
public:
    CAADCustomGateTemplate();

    void begin();
    void begin(const CAADCustomGateConfig& config);
    void reset();

    // Use this for a sensor that produces one value at a time.
    // Example: temperature, gas ADC value, water level, light level.
    CAADFeatures update(float sensorValue, uint32_t timestampMs = 0);

    // Use this when the application wants to add context importance.
    CAADFeatures updateWithContext(float sensorValue, float contextImportance, uint32_t timestampMs = 0);

    float getLastValue() const;
    float getLastRateOfChange() const;
    float getLocalMean() const;
    float getLocalVariation() const;

private:
    CAADCustomGateConfig _config;

    bool _hasLast;
    float _lastValue;
    float _lastRateOfChange;
    float _localMean;
    float _localVariation;
    float _recentPeak;
    uint8_t _persistenceCount;

    float absFloat(float value) const;
    float maxFloat(float a, float b) const;
    float clampFloat(float value, float low, float high) const;
};

#endif

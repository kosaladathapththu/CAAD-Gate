#include "CAADEnvironmentGate.h"

CAADEnvironmentGate::CAADEnvironmentGate() {
    begin();
}

void CAADEnvironmentGate::begin() {
    CAADEnvironmentConfig defaultConfig;
    begin(defaultConfig);
}

void CAADEnvironmentGate::begin(const CAADEnvironmentConfig& config) {
    _config = config;
    reset();
}

void CAADEnvironmentGate::reset() {
    _hasLast = false;
    _lastValue = 0.0f;
    _lastRate = 0.0f;
    _localMean = 0.0f;
    _localVariation = 0.0f;
    _sampleCount = 0;
    _persistenceCount = 0;
}

CAADFeatures CAADEnvironmentGate::update(float value, uint32_t timestampMs) {
    return updateWithContext(value, _config.defaultContextImportance, timestampMs);
}

CAADFeatures CAADEnvironmentGate::updateWithContext(float value, float contextImportance, uint32_t timestampMs) {
    CAADFeatures features;
    features.valid = true;
    features.timestampMs = timestampMs;

    // The main level for scalar sensors is simply the current value.
    features.level = value;

    // Rate of change shows how quickly the environmental value is changing.
    float rate = 0.0f;
    if (_hasLast) {
        rate = value - _lastValue;
    }
    _lastRate = rate;
    features.rateOfChange = rate;

    // Local variation helps the core know if the sensor is unstable.
    _sampleCount++;
    if (_sampleCount == 1) {
        _localMean = value;
        _localVariation = 0.0f;
    } else {
        float alpha = 0.05f; // local feature-only smoothing, not the core normal model
        _localMean = (_localMean * (1.0f - alpha)) + (value * alpha);
        _localVariation = (_localVariation * (1.0f - alpha)) + (absFloat(value - _localMean) * alpha);
    }
    features.variation = _localVariation;

    // For scalar environment signals, peak is the current value.
    // The core compares it against learned normal mean.
    features.peak = value;

    // Persistence evidence increases when the value keeps changing significantly.
    if (absFloat(rate) >= _config.significantChange) {
        if (_persistenceCount < _config.persistenceWindow) {
            _persistenceCount++;
        }
    } else {
        if (_persistenceCount > 0) {
            _persistenceCount--;
        }
    }

    features.durationEvidence = (_config.persistenceWindow == 0)
        ? 0.0f
        : ((float)_persistenceCount / (float)_config.persistenceWindow);

    features.contextImportance = contextImportance;
    features.confidence = 1.0f;

    // Allow normal update. The core itself will decide if the gate is closed.
    features.allowNormalUpdate = true;

    _lastValue = value;
    _hasLast = true;
    return features;
}

float CAADEnvironmentGate::getLastValue() const {
    return _lastValue;
}

float CAADEnvironmentGate::getLastRateOfChange() const {
    return _lastRate;
}

float CAADEnvironmentGate::absFloat(float value) const {
    return value < 0.0f ? -value : value;
}

float CAADEnvironmentGate::clampFloat(float value, float low, float high) const {
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

#ifndef CAAD_ENVIRONMENT_GATE_H
#define CAAD_ENVIRONMENT_GATE_H

/*
  CAADEnvironmentGate
  -------------------
  Sensor adapter for scalar environment/machine readings.

  Examples:
  - temperature
  - humidity
  - gas / air-quality value
  - machine condition value
  - battery or voltage trend

  This module does not make the final gate decision.
  It only converts raw readings into CAADFeatures for CAADGateCore.
*/

#include "../CAADTypes.h"

struct CAADEnvironmentConfig {
    // Ignore very tiny changes when building duration evidence.
    float significantChange;

    // Maximum persistence count used to normalize duration evidence.
    uint8_t persistenceWindow;

    // Optional application context importance added to each feature packet.
    float defaultContextImportance;

    CAADEnvironmentConfig()
        : significantChange(0.25f),
          persistenceWindow(5),
          defaultContextImportance(0.0f) {}
};

class CAADEnvironmentGate {
public:
    CAADEnvironmentGate();

    void begin();
    void begin(const CAADEnvironmentConfig& config);
    void reset();

    // Update using one scalar reading.
    // Example: temperature in Celsius or gas sensor value.
    CAADFeatures update(float value, uint32_t timestampMs = 0);

    // Update with custom context importance for this reading.
    CAADFeatures updateWithContext(float value, float contextImportance, uint32_t timestampMs = 0);

    float getLastValue() const;
    float getLastRateOfChange() const;

private:
    CAADEnvironmentConfig _config;
    bool _hasLast;
    float _lastValue;
    float _lastRate;
    float _localMean;
    float _localVariation;
    uint32_t _sampleCount;
    uint8_t _persistenceCount;

    float absFloat(float value) const;
    float clampFloat(float value, float low, float high) const;
};

#endif

#include "CAADMotionGate.h"
#include <math.h>

CAADMotionGate::CAADMotionGate() {
    begin();
}

void CAADMotionGate::begin() {
    CAADMotionConfig defaultConfig;
    begin(defaultConfig);
}

void CAADMotionGate::begin(const CAADMotionConfig& config) {
    _config = config;
    reset();
}

void CAADMotionGate::reset() {
    _hasLast = false;
    _lastMagnitude = 0.0f;
    _lastJerk = 0.0f;
    _recentPeak = 0.0f;
    _stillnessCount = 0;
}

CAADFeatures CAADMotionGate::update(float ax, float ay, float az, uint32_t timestampMs) {
    return updateWithContext(ax, ay, az, _config.defaultContextImportance, timestampMs);
}

CAADFeatures CAADMotionGate::updateWithContext(float ax, float ay, float az, float contextImportance, uint32_t timestampMs) {
    CAADFeatures features;
    features.valid = true;
    features.timestampMs = timestampMs;

    // Magnitude converts 3-axis acceleration into one motion level.
    float magnitude = sqrtFloat((ax * ax) + (ay * ay) + (az * az));
    float jerk = 0.0f;
    if (_hasLast) {
        jerk = absFloat(magnitude - _lastMagnitude);
    }

    _lastJerk = jerk;
    _recentPeak = maxFloat(_recentPeak * 0.92f, magnitude);

    // Stillness evidence grows when movement change is very low.
    if (_hasLast && jerk < _config.stillnessJerkThreshold) {
        if (_stillnessCount < _config.stillnessWindow) {
            _stillnessCount++;
        }
    } else {
        if (_stillnessCount > 0) {
            _stillnessCount--;
        }
    }

    float stillnessEvidence = (_config.stillnessWindow == 0)
        ? 0.0f
        : ((float)_stillnessCount / (float)_config.stillnessWindow);

    float impactEvidence = 0.0f;
    if (magnitude >= _config.strongImpactMagnitude) {
        impactEvidence = 1.0f;
    }

    features.level = magnitude;
    features.rateOfChange = jerk;
    features.variation = jerk;
    features.peak = _recentPeak;

    // For fall-candidate style logic, persistence can come from impact and stillness.
    // The downstream app can still apply more specific fall logic after the gate opens.
    features.durationEvidence = clampFloat(impactEvidence + stillnessEvidence, 0.0f, 2.0f);
    features.contextImportance = contextImportance;
    features.confidence = 1.0f;
    features.allowNormalUpdate = true;

    _lastMagnitude = magnitude;
    _hasLast = true;
    return features;
}

float CAADMotionGate::getLastMagnitude() const {
    return _lastMagnitude;
}

float CAADMotionGate::getLastJerk() const {
    return _lastJerk;
}

float CAADMotionGate::sqrtFloat(float value) const {
    if (value <= 0.0f) return 0.0f;
    return sqrtf(value);
}

float CAADMotionGate::absFloat(float value) const {
    return value < 0.0f ? -value : value;
}

float CAADMotionGate::maxFloat(float a, float b) const {
    return a > b ? a : b;
}

float CAADMotionGate::clampFloat(float value, float low, float high) const {
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

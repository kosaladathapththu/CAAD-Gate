#ifndef CAAD_MOTION_GATE_H
#define CAAD_MOTION_GATE_H

/*
  CAADMotionGate
  --------------
  Sensor adapter for accelerometer / motion data.

  Typical use:
  - eldercare movement monitoring
  - fall-candidate window forwarding
  - vibration/anomaly monitoring

  Important: This module does not medically confirm a fall.
  It creates motion features and fall-candidate evidence for CAADGateCore.
*/

#include "../CAADTypes.h"

struct CAADMotionConfig {
    // Acceleration values are assumed to be in g units if possible.
    // Example normal resting magnitude is close to 1.0g.
    float stillnessJerkThreshold;
    float strongImpactMagnitude;
    uint8_t stillnessWindow;
    float defaultContextImportance;

    CAADMotionConfig()
        : stillnessJerkThreshold(0.08f),
          strongImpactMagnitude(2.2f),
          stillnessWindow(8),
          defaultContextImportance(0.0f) {}
};

class CAADMotionGate {
public:
    CAADMotionGate();

    void begin();
    void begin(const CAADMotionConfig& config);
    void reset();

    // ax, ay, az are accelerometer axes. Use g units if your sensor library provides them.
    CAADFeatures update(float ax, float ay, float az, uint32_t timestampMs = 0);
    CAADFeatures updateWithContext(float ax, float ay, float az, float contextImportance, uint32_t timestampMs = 0);

    float getLastMagnitude() const;
    float getLastJerk() const;

private:
    CAADMotionConfig _config;
    bool _hasLast;
    float _lastMagnitude;
    float _lastJerk;
    float _recentPeak;
    uint8_t _stillnessCount;

    float sqrtFloat(float value) const;
    float absFloat(float value) const;
    float maxFloat(float a, float b) const;
    float clampFloat(float value, float low, float high) const;
};

#endif

#include "CAADSoundGate.h"

CAADSoundGate::CAADSoundGate() {
    begin();
}

void CAADSoundGate::begin() {
    CAADSoundConfig defaultConfig;
    begin(defaultConfig);
}

void CAADSoundGate::begin(const CAADSoundConfig& config) {
    _config = config;
    reset();
}

void CAADSoundGate::reset() {
    _hasLastEnergy = false;
    _lastEnergy = 0.0f;
    _lastEnergyChange = 0.0f;
    _recentPeakEnergy = 0.0f;
    _persistenceCount = 0;
}

CAADFeatures CAADSoundGate::updateEnergy(float frameEnergy, uint32_t timestampMs) {
    return updateEnergyWithContext(frameEnergy, _config.defaultContextImportance, timestampMs);
}

CAADFeatures CAADSoundGate::updateEnergyWithContext(float frameEnergy, float contextImportance, uint32_t timestampMs) {
    CAADFeatures features;
    features.valid = true;
    features.timestampMs = timestampMs;

    float change = 0.0f;
    if (_hasLastEnergy) {
        change = frameEnergy - _lastEnergy;
    }

    _lastEnergyChange = change;
    _recentPeakEnergy = maxFloat(_recentPeakEnergy * 0.90f, frameEnergy);

    if (absFloat(change) >= _config.significantEnergyChange) {
        if (_persistenceCount < _config.persistenceWindow) {
            _persistenceCount++;
        }
    } else {
        if (_persistenceCount > 0) {
            _persistenceCount--;
        }
    }

    features.level = frameEnergy;
    features.rateOfChange = change;
    features.variation = absFloat(change);
    features.peak = _recentPeakEnergy;
    features.durationEvidence = (_config.persistenceWindow == 0)
        ? 0.0f
        : ((float)_persistenceCount / (float)_config.persistenceWindow);
    features.contextImportance = contextImportance;
    features.confidence = 1.0f;
    features.allowNormalUpdate = true;

    _lastEnergy = frameEnergy;
    _hasLastEnergy = true;
    return features;
}

CAADFeatures CAADSoundGate::updateFrame(const int16_t* samples, uint16_t length, uint32_t timestampMs) {
    return updateFrameWithContext(samples, length, _config.defaultContextImportance, timestampMs);
}

CAADFeatures CAADSoundGate::updateFrameWithContext(const int16_t* samples, uint16_t length, float contextImportance, uint32_t timestampMs) {
    if (samples == 0 || length == 0) {
        CAADFeatures invalid;
        invalid.valid = false;
        invalid.timestampMs = timestampMs;
        return invalid;
    }

    float energy = computeFrameEnergy(samples, length);
    return updateEnergyWithContext(energy, contextImportance, timestampMs);
}

float CAADSoundGate::computeFrameEnergy(const int16_t* samples, uint16_t length) const {
    if (samples == 0 || length == 0) {
        return 0.0f;
    }

    // Remove DC offset.
    float mean = 0.0f;
    for (uint16_t i = 0; i < length; i++) {
        mean += (float)samples[i];
    }
    mean /= (float)length;

    // Pre-emphasis + mean square energy.
    float energySum = 0.0f;
    float previous = (float)samples[0] - mean;

    for (uint16_t i = 0; i < length; i++) {
        float current = (float)samples[i] - mean;
        float emphasized;
        if (i == 0) {
            emphasized = current;
        } else {
            emphasized = current - (_config.preEmphasisAlpha * previous);
        }
        previous = current;
        energySum += emphasized * emphasized;
    }

    return energySum / (float)length;
}

float CAADSoundGate::getLastEnergy() const {
    return _lastEnergy;
}

float CAADSoundGate::getLastEnergyChange() const {
    return _lastEnergyChange;
}

float CAADSoundGate::absFloat(float value) const {
    return value < 0.0f ? -value : value;
}

float CAADSoundGate::maxFloat(float a, float b) const {
    return a > b ? a : b;
}

float CAADSoundGate::clampFloat(float value, float low, float high) const {
    if (value < low) return low;
    if (value > high) return high;
    return value;
}

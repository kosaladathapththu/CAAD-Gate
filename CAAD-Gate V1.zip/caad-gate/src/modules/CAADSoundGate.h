#ifndef CAAD_SOUND_GATE_H
#define CAAD_SOUND_GATE_H

/*
  CAADSoundGate
  -------------
  Sensor adapter for sound/audio frame gating.

  Typical use:
  - microphone frame energy gating
  - sound-event candidate detection
  - pre-filtering before MFCC/MFBE/classification

  This module can work in two ways:
  1. updateEnergy(energy): when energy is already calculated elsewhere.
  2. updateFrame(samples, length): when raw PCM frame samples are available.
*/

#include "../CAADTypes.h"

struct CAADSoundConfig {
    // Pre-emphasis coefficient used when computing energy from raw samples.
    float preEmphasisAlpha;

    // Significant energy change for simple duration evidence.
    float significantEnergyChange;

    // Persistence window for sound event evidence.
    uint8_t persistenceWindow;

    // Optional context importance.
    float defaultContextImportance;

    CAADSoundConfig()
        : preEmphasisAlpha(0.97f),
          significantEnergyChange(1000.0f),
          persistenceWindow(5),
          defaultContextImportance(0.0f) {}
};

class CAADSoundGate {
public:
    CAADSoundGate();

    void begin();
    void begin(const CAADSoundConfig& config);
    void reset();

    // Use this when your audio frontend already calculated frame energy.
    CAADFeatures updateEnergy(float frameEnergy, uint32_t timestampMs = 0);
    CAADFeatures updateEnergyWithContext(float frameEnergy, float contextImportance, uint32_t timestampMs = 0);

    // Use this for raw PCM frames. Samples can be int16_t audio samples.
    CAADFeatures updateFrame(const int16_t* samples, uint16_t length, uint32_t timestampMs = 0);
    CAADFeatures updateFrameWithContext(const int16_t* samples, uint16_t length, float contextImportance, uint32_t timestampMs = 0);

    float computeFrameEnergy(const int16_t* samples, uint16_t length) const;
    float getLastEnergy() const;
    float getLastEnergyChange() const;

private:
    CAADSoundConfig _config;
    bool _hasLastEnergy;
    float _lastEnergy;
    float _lastEnergyChange;
    float _recentPeakEnergy;
    uint8_t _persistenceCount;

    float absFloat(float value) const;
    float maxFloat(float a, float b) const;
    float clampFloat(float value, float low, float high) const;
};

#endif

/*
  Portable compile test for CAAD-Gate core and modules.
  This test is not an Arduino sketch. It checks whether the reusable C++ parts
  compile in a normal C++ environment.
*/

#include <iostream>
#include "../src/CAADGateCore.h"
#include "../src/modules/CAADSoundGate.h"
#include "../src/modules/CAADMotionGate.h"
#include "../src/modules/CAADEnvironmentGate.h"
#include "../src/modules/CAADCustomGateTemplate.h"

int main() {
    CAADGateCore core;
    CAADConfig config;
    config.warmupWindows = 3;
    core.begin(config);

    CAADContext context;
    context.sensitivity = 0.1f;
    context.batteryPercent = 100.0f;

    CAADEnvironmentGate env;
    env.begin();

    CAADMotionGate motion;
    motion.begin();

    CAADSoundGate sound;
    sound.begin();

    CAADCustomGateTemplate custom;
    custom.begin();

    for (int i = 0; i < 20; i++) {
        float value = (i < 10) ? 40.0f : 55.0f;
        CAADFeatures f = env.update(value, (uint32_t)i);
        CAADDecision d = core.update(f, context);
        (void)d;
    }

    int16_t samples[8] = {1, -1, 2, -2, 1, -1, 2, -2};
    CAADFeatures sf = sound.updateFrame(samples, 8, 100);
    CAADDecision sd = core.update(sf, context);
    (void)sd;

    CAADFeatures mf = motion.update(0.1f, 0.1f, 1.0f, 200);
    CAADDecision md = core.update(mf, context);
    (void)md;

    CAADFeatures cf = custom.update(123.0f, 300);
    CAADDecision cd = core.update(cf, context);
    (void)cd;

    std::cout << "CAAD-Gate portable compile test PASS" << std::endl;
    return 0;
}
